<?php

namespace App;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;


class ContentSubtitles extends Model
{
    use HasFactory;
    protected $table = 'tbl_content_subtitles';
 
}
