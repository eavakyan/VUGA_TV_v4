var domainUrl = $("#appUrl").val();


// If you want to enable TMDB (Optional)
var TMDB_api_key = $("#TMDB_API_KEY").val();