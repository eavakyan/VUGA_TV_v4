$(document).ready(function () {
    $(".sideBarli").removeClass("activeLi");
    $(".indexSideA").addClass("activeLi");
});