<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

// TV Authentication Routes
Route::prefix('tv/auth')->group(function () {
    Route::post('generate', 'TVAuthController@generateAuthSession');
    Route::post('check', 'TVAuthController@checkAuthStatus');
    Route::post('authenticate', 'TVAuthController@authenticateSession');
    Route::post('complete', 'TVAuthController@completeAuth');
});

// Include old app routes if they exist
$oldApiPath = base_path('../old_app/routes/api.php');
if (file_exists($oldApiPath)) {
    require $oldApiPath;
}